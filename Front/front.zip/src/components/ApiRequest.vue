<template>
    <div>
      <h1>Realizar una solicitud a una API</h1>
      <input v-model="ciudad1" placeholder="Ciudad 1" />
      <input v-model="ciudad2" placeholder="Ciudad 2" />
      <button @click="enviarSolicitud('CSV')">CSV</button>
      <button @click="enviarSolicitud('API')">API</button>
      <button @click="enviarSolicitud('MOCK')">MOCK</button>
      <div v-if="respuesta">
        <h2>Respuesta:</h2>
        <pre>{{ respuesta }}</pre>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        respuesta: null,
        ciudad1: "",
        ciudad2: "",
      };
    },
    methods: {
      async enviarSolicitud(tecnica) {
        const url = `http://192.168.19.7:3001/distance?city1=${this.ciudad1.toLowerCase()}&city2=${this.ciudad2.toLowerCase()}&method=${tecnica}`;
        try {
          const response = await this.$axios.post(url);
          this.respuesta = response.data;
          console.log(response.data);
        } catch (error) {
          console.error('Error al hacer la solicitud:', error);
          console.log(this.respuesta);
          this.respuesta = 'Error al hacer la solicitud.';
        }
      },
    },
  };
  </script>
  
  <style>
  /* Estilos CSS aquí si es necesario */
  </style>
  