import { createApp } from 'vue';
import App from './App.vue';
import axios from 'axios';

const app = createApp(App);
app.config.globalProperties.$axios = axios.create({
  baseURL: 'http://10.100.233.101:3003/distance'
});
app.mount('#app');
